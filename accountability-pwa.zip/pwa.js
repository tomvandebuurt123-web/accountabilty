document.getElementById("date").textContent =
  new Date().toLocaleDateString();